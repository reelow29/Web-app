To build project need to do this commands:
npm install
cd shop_1
npm run