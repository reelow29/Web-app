import React from "react";
import Header from "./components/Header/Header";
import MainPage from "./components/MainPage/MainPage";
import Items from "./components/Items";


class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            orders: [],
            currentItems: [],
            items: [
                {
                  id: 1,
                  title: 'Paracetamol',
                  img: 'tabl.png',
                  desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                  category: 'first category',
                  price: '29.99$'
                },
                {
                    id: 2,
                    title: 'Mezum',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'first category',
                    price: '69$'
                },
                {
                    id: 3,
                    title: 'Espumizan',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'first category',
                    price: '15.40$'
                },
                {
                    id: 4,
                    title: 'Novirun',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'first category',
                    price: '77.90$'
                },
                {
                    id: 5,
                    title: 'Farmadol',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'second category',
                    price: '54.30$'
                },
                {
                    id: 6,
                    title: 'Extenreact',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'second category',
                    price: '70.5$'
                },
                {
                    id: 7,
                    title: 'KardioMag',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'second category',
                    price: '17.99$'
                },
                {
                    id: 8,
                    title: 'Vitamin D',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'third category',
                    price: '86.5$'
                },
                {
                    id: 9,
                    title: 'Plafns',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'third category',
                    price: '23.5$'
                },
                {
                    id: 10,
                    title: 'Ostencort',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'third category',
                    price: '10.10$'
                },
                {
                    id: 11,
                    title: 'Kordoak',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'fourth category',
                    price: '87.3$'
                },
                {
                    id: 12,
                    title: 'Lindete',
                    img: 'tabl.png',
                    desc: 'Lorem ipsum dolor sit amet, conddsplr adoppindna',
                    category: 'fourth category',
                    price: '24.5$'
                },

            ]
        }
        this.state.currentItems = this.state.items
        this.addToOrder = this.addToOrder.bind(this)
        this.deleteOrder = this.deleteOrder.bind(this)
        this.chooseCategory = this.chooseCategory.bind(this)
    }
    render() {
        return (
            <div className='wrapper'>
                <Header orders={this.state.orders} onDelete={this.deleteOrder} />
                <MainPage chooseCategory={this.chooseCategory}/>
                <Items items={this.state.currentItems} onAdd={this.addToOrder}/>
            </div>
        );
    }

    chooseCategory(category) {
        if(category === 'all') {
            this.setState({currentItems: this.state.items})
            return
        }

        this.setState({
            currentItems: this.state.items.filter(el => el.category === category)
        })
    }

    deleteOrder(id) {
      this.setState({orders: this.state.orders.filter(el => el.id !==id )})
    }

    addToOrder(item) {
        let isInArray = false
        this.state.orders.forEach(el => {
            if (el.id === item.id)
                isInArray = true
        })
        if (!isInArray)
            this.setState({orders: [...this.state.orders, item]})
    }
}



export default App;
