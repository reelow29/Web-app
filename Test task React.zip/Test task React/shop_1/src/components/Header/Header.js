import React, {useState} from 'react';
import './/header.css'
import Order from "../Order";

const showOrders = (props) => {
    let sum = 0;
    props.orders.forEach(el => sum += Number.parseFloat(el.price))
    return (
    <div>
        {props.orders.map(el =>(
            <Order onDelete={props.onDelete} key={el.id} item={el} />
        ))}
        <p className='sum'>Sum: {sum.toFixed(2)}$</p>
    </div>
        );
}

const showNothing = () => {
    return (
        <div className='empty'>
            <h2>The basket is empty</h2>
        </div>
    )
}

function Header(props) {
    let [cartOpen, setCartOpen] = useState(false);

        return (
            <header>
                <a className='shop' href={'#'}>Shop</a>
                <div className="divider"></div>
                <a onClick={() => setCartOpen(cartOpen = !cartOpen)} className={`shopping cart ${cartOpen && 'active'}`}
                   href={'#'}>Shopping Cart</a>
                {cartOpen && (
                    <div className='shop-cart'>
                        {props.orders.length > 0 ?
                            showOrders(props) : showNothing()}
                    </div>
                )}
            </header>
        );
}

export default Header;
