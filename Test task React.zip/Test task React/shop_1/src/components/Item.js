import React, {Component} from 'react';

class Item extends Component {
    render() {
        return (
            <div>
                <div className="item">
                    <img src={"./img/" + this.props.item.img} alt=""/>
                    <h2>{this.props.item.title}</h2>
                    <p>{this.props.item.price}</p>
                    <div className='add-to-cart' onClick={()=> this.props.onAdd(this.props.item)}>Add to Cart</div>
                </div>
            </div>
        );
    }
}

export default Item;
