import React, { Component } from 'react';
import './mainpage.css';


class MainPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            categories: [
                {
                    key: 'all',
                    name: 'All drugs'

                },

                {
                    key: 'first category',
                    name: 'Drugs 24'
                },

                {
                    key: 'second category',
                    name: 'Pharmacy'
                },

                {
                    key: 'third category',
                    name: 'Plantain'
                },

                {
                    key: 'fourth category',
                    name: 'Social Pharmacy'
                },

                {
                    key: 'second category',
                    name: '24/7 Pharmacy'
                },
            ]
        }
    }
    render() {
        return (
            <div className='categories'>
                <h2 className='header_sidebar'>Pharmacies:</h2>
                {this.state.categories.map(el => (
                    <div key={el.key} onClick={()=> this.props.chooseCategory(el.key)}>{el.name}</div>
                ))}
            </div>
        );
    }


}




export default MainPage;